﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Path = System.IO.Path;
using Newtonsoft.Json;
using MetroRail.view.item;

namespace MetroRail.view.item
{
    /// <summary>
    /// Interaction logic for ticketallinfo.xaml
    /// </summary>
    public partial class ticketallinfo : Window
    {
        public ticketallinfo()
        {
            InitializeComponent();
        }
        public static string  mid  = "";
        public static string pid = "";
        public static string name = "";
        public static string contact = "";
        public static string stoppage = "";
        public static int price=0;

        private void GetTicketList()
        {
            var json = File.ReadAllText(@"ticketa.json");
            var jObject = JObject.Parse(json);
            if (jObject != null)
            {
                JArray history = (JArray)jObject["ticketa"];
                if (history != null)
                {
                    List<tickethistory> tickethistories = new List<tickethistory>();
                    foreach (var t in history)
                    {
                        tickethistories.Add(new tickethistory() { MetroId = t["MetroId"].ToString(), PassengerId = t["PassengerId"].ToString(), Name = t["Name"].ToString(), Contact = t["Contact"].ToString(), Stoppage = t["Stoppage"].ToString(), Price=Convert.ToInt32(t["Price"]) });

                    }
                    lvtickets.ItemsSource = tickethistories;
                }
            }
        }

        private void btnview_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            var itemsJson = File.ReadAllText(@"ticketa.json");
            try
            {
                var jObject = JObject.Parse(itemsJson);
                JArray itemArr = (JArray)jObject["ticketa"];
                Button button = sender as Button;
                item.tickethistory history = button.CommandParameter as item.tickethistory;
                string iId = history.MetroId;
                var itemToDelete = itemArr.FirstOrDefault(obj => obj["MetroId"].Value<string>() == iId);

                MessageBox.Show("Are you sure to delete this product?");
                itemArr.Remove(itemToDelete);

                string output = Newtonsoft.Json.JsonConvert.SerializeObject(jObject, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(@"ticketa.json", output);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                MessageBox.Show("Data deleted successfully!!!");
                GetTicketList();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetTicketList();
        }

        private void lvtickets_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
