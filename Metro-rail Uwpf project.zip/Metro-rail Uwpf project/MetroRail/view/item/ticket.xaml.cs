﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace MetroRail.view.item
{
    /// <summary>
    /// Interaction logic for ticket.xaml
    /// </summary>
    public partial class ticket : Window
    {
        public ticket()
        {
            InitializeComponent();

            List<string> stoppage = new List<string>()
            {
                "Mirpur To Uttra",
                "Uttra To Mirpur",
                "Agargaon To Motijil",
                
            };
            List<int> price = new List<int>()
            {
                30,40,50,70,80
                
            };
            cmbstoppage.ItemsSource = stoppage;
            cmbprice.ItemsSource = price;
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
             mainWindow.Visibility = Visibility.Visible;
             Window win = (Window)this.Parent;
             this.Hide();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
            mainWindow.Visibility = Visibility.Visible;
            Window win = (Window)this.Parent;
            this.Hide();
        }

        private void btnsave_Click(object sender, RoutedEventArgs e)
        {
            item.tickethistory t = new item.tickethistory();
            t.MetroId = txtmetroid.Text;
            t.PassengerId = txtpassengerid.Text;
            t.Name = txtname.Text;
            t.Contact = txtcontact.Text;
            t.Stoppage = cmbstoppage.Text;
            t.Price = Convert.ToInt32(cmbprice.Text);

            var newitem = "{'MetroId':'" + t.MetroId + "','PassengerId':'" + t.PassengerId + "','Name':'" + t.Name + "','Contact':'" + t.Contact + "','Stoppage':'" + t.Stoppage + "','Price':'" + t.Price + "'}";
            var itemjson = File.ReadAllText(@"ticketa.json");
            var jsonobject = JObject.Parse(itemjson);
            var itemArr = jsonobject.GetValue("ticketa") as JArray;
            var ticket = JObject.Parse(newitem);
            itemArr.Add(ticket);

            jsonobject["ticketa"] = itemArr;
            string jsonResult = JsonConvert.SerializeObject(jsonobject, Formatting.Indented);
            File.WriteAllText(@"ticketa.json", jsonResult);

        }

        private void btnshowdata_Click(object sender, RoutedEventArgs e)
        {
            ticketallinfo info = new ticketallinfo();
            info.Show();
        }
    }
}
