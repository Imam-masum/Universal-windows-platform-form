﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetroRail.view.item
{
    public class tickethistory
    {
        public string MetroId { get; set; }
        public string  PassengerId { get; set; }
        public string Name { get; set; }
        public string Contact { get; set; }
        public string Stoppage { get; set; }
        public int Price { get; set; }
       
    }

}